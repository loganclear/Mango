import SwiftUI

struct MGDNSEntranceView: View {
    
    var body: some View {
        NavigationLink {
            
        } label: {
            Label("DNS", systemImage: "network")
        }
    }
}
